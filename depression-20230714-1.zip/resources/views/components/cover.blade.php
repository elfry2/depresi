<div id="cover" class="h-100 w-100 position-fixed top-0 left-0 bg-white" style="z-index:9999">
<div class="d-flex align-items-center justify-content-center h-100">
    <a href="http://" target="_blank" rel="noopener noreferrer">
        <img src="/images/loading.gif" alt="Loading...">
    </a>
</div>
</div>
<script>
    window.addEventListener('load', function() {
        document.getElementById('cover').style.display = 'none';
    });
</script>