<a data-bs-target="#itemCreationModal" data-bs-toggle="modal" class="hide-on-small-screens btn btn-outline-dark border-0 me-1" href="#"
        title="Tambah {{ strtolower($title) }}"><i class="bi-plus-lg"></i>Tambah</a>
<a href="#" data-bs-target="#itemCreationModal" data-bs-toggle="modal">
    <div class="d-flex justify-content-center align-items-center hide-on-big-screens btn bg-white border shadow text-dark" style="width: 4em; height: 4em; border-radius: 50%; position: fixed; bottom: 1em; right: 1em; z-index: 1">
        <span class="h3 m-0"><i class="bi-plus-lg"></i></span>
    </div>
</a>